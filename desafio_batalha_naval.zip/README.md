
# Desafio Batalha Naval

Projeto desenvolvido como parte da disciplina de programação.

## 🎯 Objetivo

Criar uma versão simples do jogo Batalha Naval em Python, onde o jogador tenta acertar a posição de um navio no tabuleiro inimigo.

## ▶️ Como executar

1. Instale o Python 3 em seu computador.
2. Execute o código com:

```bash
python main.py
```

3. Tente acertar o navio escondido no tabuleiro inimigo!

## 👤 Autor

Wesley Moura

## 📅 Entrega

Prazo final: 17/06/2025
