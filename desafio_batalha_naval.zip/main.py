
import random

def criar_tabuleiro(tamanho):
    return [["~"] * tamanho for _ in range(tamanho)]

def exibir_tabuleiro(tabuleiro):
    for linha in tabuleiro:
        print(" ".join(linha))

def posicionar_navio(tabuleiro, tamanho_navio):
    while True:
        orientacao = random.choice(["H", "V"])
        if orientacao == "H":
            linha = random.randint(0, len(tabuleiro) - 1)
            coluna = random.randint(0, len(tabuleiro) - tamanho_navio)
            if all(tabuleiro[linha][coluna + i] == "~" for i in range(tamanho_navio)):
                for i in range(tamanho_navio):
                    tabuleiro[linha][coluna + i] = "N"
                break
        else:
            linha = random.randint(0, len(tabuleiro) - tamanho_navio)
            coluna = random.randint(0, len(tabuleiro) - 1)
            if all(tabuleiro[linha + i][coluna] == "~" for i in range(tamanho_navio)):
                for i in range(tamanho_navio):
                    tabuleiro[linha + i][coluna] = "N"
                break

def jogar():
    tamanho = 5
    tabuleiro_jogador = criar_tabuleiro(tamanho)
    tabuleiro_inimigo = criar_tabuleiro(tamanho)
    posicionar_navio(tabuleiro_inimigo, 3)

    tentativas = 5
    while tentativas > 0:
        print(f"Você tem {tentativas} tentativas restantes.")
        exibir_tabuleiro(tabuleiro_jogador)
        linha = int(input("Escolha a linha (0 a 4): "))
        coluna = int(input("Escolha a coluna (0 a 4): "))

        if tabuleiro_inimigo[linha][coluna] == "N":
            print("💥 Acertou!")
            tabuleiro_jogador[linha][coluna] = "X"
            break
        else:
            print("🌊 Errou!")
            tabuleiro_jogador[linha][coluna] = "O"
            tentativas -= 1

    print("Tabuleiro final:")
    exibir_tabuleiro(tabuleiro_jogador)

if __name__ == "__main__":
    jogar()
